# frozen_string_literal: false
class Gem::Package::Source # :nodoc:
end

